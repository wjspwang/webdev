<html>
<body>
<form action = "login1.php" method = "post">
-Arstotzkan Only!-<br>
Username: <input type = "text" name = "user""><br>
Password: <input type = "password" name = "pass" "><br>
<input name="login" type="submit" value="Login"></form><br> 
Don't have an account yet ?<br>
<form action = "register.php">
<input type="submit" value="Sign up"> </form>




</body>
</html>